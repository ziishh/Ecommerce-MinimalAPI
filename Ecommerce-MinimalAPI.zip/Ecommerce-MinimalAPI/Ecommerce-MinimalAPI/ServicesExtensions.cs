﻿using Ecommerce_MinimalAPI.Data;
using Ecommerce_MinimalAPI.Services.Implementations;
using Ecommerce_MinimalAPI.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Ecommerce_MinimalAPI
{
	public static class ServicesExtensions
	{
		public static IServiceCollection AddServices (this IServiceCollection services, IConfiguration configuration)
		{
			services.AddDbContext<DataContext>(opt =>
			{
				opt.UseSqlServer(configuration.GetConnectionString("Default"));
			});
			services.AddScoped<IProductService, ProductService>()
				.AddScoped<ICategoryService, CategoryService>();
			return services;
		}
	}
}
