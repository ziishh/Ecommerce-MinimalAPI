using Ecommerce_MinimalAPI;
using Ecommerce_MinimalAPI.Data;
using Ecommerce_MinimalAPI.Filters;
using Ecommerce_MinimalAPI.Requests;
using Ecommerce_MinimalAPI.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddServices(builder.Configuration);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
	app.UseSwagger();
	app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// Products
var products = app.MapGroup("/products").WithTags("Products");
products.MapGet("/", async (IProductService productService, decimal? minPrice, decimal? maxPrice,
			string? categoryName, string? productName, string? productDescription) 
			=> await productService.GetAllProducts(minPrice, maxPrice, categoryName, productName, productDescription));

products.MapPost("/", async (IProductService productService, ProductRequest request)
	=> await productService.CreateProduct(request))
	.AddEndpointFilter(new ProductEndpointFilters().ValidateCreateRequest);

products.MapPut("/{id}", async (IProductService productService, int id, ProductRequest request)
	=> await productService.UpdateProduct(id, request))
	.AddEndpointFilter(new ProductEndpointFilters().ValidateUpdateRequest);

products.MapGet("/{id}", async (IProductService productService, int id)
	=> await productService.GetProducById(id));
products.MapGet("/average", async (IProductService productService)
	=> await productService.GetAverage());
products.MapDelete("/{id}", async (IProductService productService, int id) 
	=> await productService.DeleteProduct(id));

// Categories
var categories = app.MapGroup("/categories").WithTags("Categories");
categories.MapGet("/", async (ICategoryService categoryService) 
	=> await categoryService.GetAllCategories());

categories.MapPut("/{id}", async (ICategoryService categoryService, int id, CategoryRequest request)
	=> await categoryService.UpdateCategory(id, request))
	.AddEndpointFilter(CategoryEndpointFilters.ValidateUpdateRequest);

categories.MapPost("/", async (ICategoryService categoryService, CategoryRequest request)
	=> await categoryService.CreateCategory(request))
	.AddEndpointFilter(CategoryEndpointFilters.ValidateCreateRequest);

categories.MapGet("/{id}", async(ICategoryService categoryService, int id) 
	=> await categoryService.GetCategoryById(id));

categories.MapGet("/count", async (ICategoryService categoryService)
	=> await categoryService.GetNumberOfCategories());

categories.MapDelete("/{id}", async (ICategoryService categoryService, int id)
	=> await categoryService.DeleteCategory(id));

app.Run();