﻿namespace Ecommerce_MinimalAPI.Requests
{
	public record CategoryRequest
	{
		public string Name { get; set; }
	}
}
