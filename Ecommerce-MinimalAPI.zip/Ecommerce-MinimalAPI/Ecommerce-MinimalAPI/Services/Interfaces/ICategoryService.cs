﻿using Ecommerce_MinimalAPI.Requests;

namespace Ecommerce_MinimalAPI.Services.Interfaces
{
	public interface ICategoryService
	{
		Task<IResult> GetAllCategories();
		Task<IResult> GetCategoryById(int id);
		Task<IResult> UpdateCategory(int id, CategoryRequest request);
		Task<IResult> CreateCategory(CategoryRequest request);
		Task<IResult> GetNumberOfCategories();
		Task<IResult> DeleteCategory(int id);
	}
}
