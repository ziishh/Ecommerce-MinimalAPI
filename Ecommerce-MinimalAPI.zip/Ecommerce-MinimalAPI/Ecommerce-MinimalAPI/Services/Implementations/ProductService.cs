﻿using Ecommerce_MinimalAPI.Data;
using Ecommerce_MinimalAPI.Models;
using Ecommerce_MinimalAPI.Requests;
using Ecommerce_MinimalAPI.Services.Interfaces;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;

namespace Ecommerce_MinimalAPI.Services.Implementations
{
	public class ProductService : IProductService
	{
		private readonly DataContext _context;

		public ProductService(DataContext context)
        {
			_context = context;
		}
        public async Task<IResult> CreateProduct(ProductRequest request)
		{
			var newProduct = new Product
			{
				Name = request.Name,
				Description = request.Description,
				Price = request.Price,
				CategoryId = request.CategoryId,
			};
			await _context.AddAsync(newProduct);
			await _context.SaveChangesAsync();
			return Results.Created($"/products/{newProduct.Id}", newProduct);
		}

		public async Task<IResult> DeleteProduct(int id)
		{
			var product = await _context.Products.FirstOrDefaultAsync(x => x.Id == id);
			if(product is null)
			{
				return Results.NotFound("Product Not Found");
			}
			_context.Products.Remove(product);
			await _context.SaveChangesAsync();
			return Results.Ok("Product is deleted");
		}

			public async Task<IResult> GetAllProducts(decimal? minPrice, decimal? maxPrice,
				string? categoryName, string? productName, string? productDescription)
			{
				var query = _context.Products
					.Include(x => x.Category)
					.AsQueryable();
				if(minPrice is not null)
				{
					query = query.Where(x => x.Price >= minPrice);
				}
				if(maxPrice is not null)
				{
					query = query.Where(x => x.Price <= maxPrice);
				}
				if(categoryName is not null)
				{
					query = query.Where(x => x.Category.Name.Contains(categoryName));
				}
				if(productName is not null)
				{
				 	query = query.Where(x => x.Name.Contains(productName));
				}
				if(productDescription is not null)
				{
					query = query.Where(x => x.Description.Contains(productDescription));
				}
				return Results.Ok(await query.ToListAsync());
			}

		public async Task<IResult> GetAverage()
		{
			var count = await _context.Products.CountAsync();
			if(count == 0)
			{
				return Results.Ok(0);
			} // for some reason, AverageAsync throws an exception if there are not products and doesn't return 0
			// so this is to solve it and return 0 when count is 0
			var average = await _context.Products.AverageAsync(x => x.Price);
			return Results.Ok(average);
		}

		public async Task<IResult> GetProducById(int id)
		{
			var product = await _context.Products.Include(x => x.Category).FirstOrDefaultAsync(x => x.Id == id);
			if(product is null)
			{
				return Results.NotFound("Product Not Found");
			}
			return Results.Ok(product);
		}

		public async Task<IResult> UpdateProduct(int id, ProductRequest request)
		{
			var product = await _context.Products.FirstOrDefaultAsync(x => x.Id == id);
			if(product is null)
			{
				return Results.NotFound("Product Not Found");
			}
			product.Update(request.Name, request.Description, request.Price, request.CategoryId);
			await _context.SaveChangesAsync();
			return Results.Ok(product);
		}
	}
}
