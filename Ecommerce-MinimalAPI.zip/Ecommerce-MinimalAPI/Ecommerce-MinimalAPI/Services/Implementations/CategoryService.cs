﻿using Ecommerce_MinimalAPI.Data;
using Ecommerce_MinimalAPI.Models;
using Ecommerce_MinimalAPI.Requests;
using Ecommerce_MinimalAPI.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Ecommerce_MinimalAPI.Services.Implementations
{
	public class CategoryService : ICategoryService
	{
		private readonly DataContext _context;

		public CategoryService(DataContext context)
        {
			_context = context;
		}
        public async Task<IResult> CreateCategory(CategoryRequest request)
		{
			var newCategory = new Category
			{
				Name = request.Name,
			};
			await _context.AddAsync(newCategory);
			await _context.SaveChangesAsync();
			return Results.Created($"/categories/{newCategory.Id}", newCategory);
		}

		public async Task<IResult> DeleteCategory(int id)
		{
			var cat = await _context.Categories.FirstOrDefaultAsync(c => c.Id == id);
			if(cat is null)
			{
				return Results.NotFound("Category does not exist");
			}
			_context.Categories.Remove(cat);
			await _context.SaveChangesAsync();
			return Results.Ok("Category and it's related products have been deleted");
		}

		public async Task<IResult> GetAllCategories()
		{
			return Results.Ok(await _context.Categories.ToListAsync());
		}

		public async Task<IResult> GetCategoryById(int id)
		{
			var category = await _context.Categories.FirstOrDefaultAsync(c => c.Id == id);
			if(category is null)
			{
				return Results.NotFound("Category not found");
			}
			return Results.Ok(category);
		}

		public async Task<IResult> GetNumberOfCategories()
		{
			var number = await _context.Categories.CountAsync();
			return Results.Ok(number);
		}

		public async Task<IResult> UpdateCategory(int id, CategoryRequest request)
		{
			var category = await _context.Categories.FirstOrDefaultAsync(c => c.Id == id);
			if(category is null)
			{
				return Results.NotFound("Category not found");
			}
			category.Update(request.Name);
			await _context.SaveChangesAsync();
			return Results.Ok(category);
		}
	}
}
